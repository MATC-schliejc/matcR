#' Internal functions used in write_fwf and read_matc_fwf
#' @param lo a dataframe with fwf layout dimensions (internally fwf_layout)
#' @param x a vector of values
#' @noRd
#' @keywords internal
#' @export
#'


getWidths <- function(lo,x){
  #lo %>% dplyr::filter(.data$record_id == x) %>% dplyr::pull(.data$width)
  lo[lo$record_id == toupper(x),c('width')]   #baseR
}

getFields <- function(lo,x){
 # lo %>% dplyr::filter(.data$record_id == x) %>% dplyr::pull(.data$data_element_name)
  lo[lo$record_id == toupper(x),c('data_element_name')]   #baseR
}

getColType <- function(lo,x){
  #reads all columns as strings
  #paste0(rep('c',nrow(lo %>% dplyr::filter(.data$record_id == x))), collapse = "")
  paste0(rep('c',nrow(lo[lo$record_id == toupper(x),])), collapse = "")
}
